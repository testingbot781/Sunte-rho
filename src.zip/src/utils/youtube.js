const axios = require('axios');
const { ytApiKey } = require('../config');
const { spawn } = require('child_process');

module.exports = {
    async search(query) {
        const url = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&q=${encodeURIComponent(query)}&key=${ytApiKey}&maxResults=1`;
        const { data } = await axios.get(url);
        if (!data.items || !data.items.length) return null;
        const video = data.items[0];
        return {
            id: video.id.videoId,
            title: video.snippet.title,
            channelTitle: video.snippet.channelTitle,
            thumbnail: video.snippet.thumbnails.default.url
        };
    },

    // Use yt-dlp to get mp3 stream
    async downloadMp3Stream(videoId) {
        return new Promise((resolve, reject) => {
            // Requires yt-dlp and ffmpeg installed in host
            const ytdlp = spawn('yt-dlp', [
                '-f', 'bestaudio',
                '--extract-audio',
                '--audio-format', 'mp3',
                '-o', '-', // Output to stdout
                `https://youtube.com/watch?v=${videoId}`
            ]);
            ytdlp.on('error', reject);
            resolve(ytdlp.stdout);
        });
    }
};