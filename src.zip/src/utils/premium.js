const { MongoClient } = require('mongodb');
const { mongoUrl } = require('../config');

let client;
async function getUsersCollection() {
    if (!client) client = await MongoClient.connect(mongoUrl, { useUnifiedTopology: true });
    const db = client.db('telegrambot');
    return db.collection('premium_users');
}

module.exports = {
    async isPremium(userId) {
        const col = await getUsersCollection();
        const user = await col.findOne({ userId: String(userId) });
        if (!user) return false;
        return new Date(user.expiresAt) > new Date();
    },
    async addUser(userId, days) {
        const col = await getUsersCollection();
        const expiresAt = new Date(Date.now() + (days * 86400000));
        await col.updateOne(
            { userId: String(userId) },
            { $set: { userId: String(userId), expiresAt } },
            { upsert: true }
        );
    },
    async removeUser(userId) {
        const col = await getUsersCollection();
        await col.deleteOne({ userId: String(userId) });
    },
    async getAllUsers() {
        const col = await getUsersCollection();
        const users = await col.find({}).toArray();
        return users.filter(u => new Date(u.expiresAt) > new Date()).map(u => u.userId);
    }
};