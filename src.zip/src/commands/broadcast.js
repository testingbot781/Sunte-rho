const config = require('../config');
const premium = require('../utils/premium');

module.exports = async (ctx) => {
    if (ctx.from.id !== Number(config.ownerId)) return ctx.reply('Only owner can use this.');
    const message = ctx.message.text.split(' ').slice(1).join(' ');
    if (!message) return ctx.reply('Usage: /broadcast <message>');
    const users = await premium.getAllUsers();
    for (const userId of users) {
        try { await ctx.telegram.sendMessage(userId, message); } catch {}
    }
    ctx.reply(`Broadcasted to ${users.length} users.`);
};