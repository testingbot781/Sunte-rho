const yt = require('../utils/youtube');
const premium = require('../utils/premium');

module.exports = async (ctx) => {
    const userId = ctx.from.id;
    const query = ctx.message.text.trim();
    if (!query) return ctx.reply('Please enter a song name.');

    // Optional: Check if user is premium for faster/advanced
    const isPremium = await premium.isPremium(userId);

    // Search YouTube
    const video = await yt.search(query);
    if (!video) return ctx.reply('Song not found.');

    // Download mp3 (via yt-dlp, streaming)
    try {
        await ctx.replyWithChatAction('upload_audio');
        const stream = await yt.downloadMp3Stream(video.id);
        await ctx.replyWithAudio({ source: stream }, {
            title: video.title,
            performer: video.channelTitle,
            thumb: video.thumbnail
        });
    } catch (e) {
        ctx.reply('Error getting song MP3.');
    }
};