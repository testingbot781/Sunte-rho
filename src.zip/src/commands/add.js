const premium = require('../utils/premium');
const config = require('../config');

module.exports = async (ctx) => {
    if (ctx.from.id !== Number(config.ownerId)) return ctx.reply('Only owner can use this.');
    const [_, userId, days] = ctx.message.text.split(' ');
    if (!userId || !days) return ctx.reply('Usage: /add <user_id> <days>');
    await premium.addUser(userId, days);
    ctx.reply(`Premium added for user ${userId} for ${days} days.`);
};