const config = require('../config');

module.exports = async (ctx) => {
    const fileName = ctx.message.text.split(' ').slice(1).join(' ');
    if (!fileName) return ctx.reply('Usage: /file <filename>');

    // Search message in channel (basic: search last 100 msgs for file/doc/name)
    const messages = await ctx.telegram.getChatHistory(config.channelId, { limit: 100 });
    for (const msg of messages) {
        if (msg.document && msg.document.file_name && msg.document.file_name.includes(fileName)) {
            return ctx.replyWithDocument(msg.document.file_id);
        }
    }
    ctx.reply('File not found in channel.');
};