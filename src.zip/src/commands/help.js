module.exports = async (ctx) => {
    await ctx.reply(`
How to use ${ctx.botInfo.username}:

🔹 Song Search:
    - Type song name in DM. Example: "Imagine Dragons Believer"
    - You get MP3 files instantly.

🔹 Get files from channel:
    - /file <filename>
    - Example: /file lecture1.pdf

🔹 Premium:
    - Owner: /add <user_id> <days> (give premium to user for X days)
    - Remove Premium: /rem <user_id>
    - Broadcast message: /broadcast <message>

Premium users get access to special features (may be faster/unlimited).

Contact Owner for premium: @technicalserena
`);
};