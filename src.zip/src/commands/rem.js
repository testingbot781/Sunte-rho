const premium = require('../utils/premium');
const config = require('../config');

module.exports = async (ctx) => {
    if (ctx.from.id !== Number(config.ownerId)) return ctx.reply('Only owner can use this.');
    const [_, userId] = ctx.message.text.split(' ');
    if (!userId) return ctx.reply('Usage: /rem <user_id>');
    await premium.removeUser(userId);
    ctx.reply(`Premium removed for user ${userId}.`);
};